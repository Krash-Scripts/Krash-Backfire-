local ESX = exports.es_extended:getSharedObject()

local uiOpen = false
local runtime = {
    vehicle = 0,
    netId = 0,
    plate = nil,
    settings = nil,
    lastRelease = 0,
    lastLaunch = 0,
    previousThrottle = false,
    peakRpm = 0.0,
    loading = false
}

local frequencyById = {}
local colorById = {}
local soundById = {}
local sizeById = {}
local engineSoundById = {}
local blockedModels = {}
local nitroPulseTokenByVehicle = {}
local activePtfxByVehicle = {}
local ptfxAssetRequestedAt = {}
local ptfxAssetWarned = {}
local flameTextureReady = false
local flameTextureAttempted = false
local flameTextureWarned = false
local engineAudioReadyAt = GetGameTimer() + Config.EngineAudio.loadDelay
-- Remember the engine audio per vehicle, not just the last vehicle seen.
-- FORCE_USE_AUDIO_GAME_OBJECT may retune GTA radio whenever it is called.
local engineAppliedByVehicle = {}
local engineBankAvailable = {}
local engineBankWarned = {}
local applyEngineSound

for i = 1, #Config.Frequencies do
    frequencyById[Config.Frequencies[i].id] = Config.Frequencies[i]
end

for i = 1, #Config.Colors do
    colorById[Config.Colors[i].id] = Config.Colors[i]
end

for i = 1, #Config.Sounds do
    soundById[Config.Sounds[i].id] = Config.Sounds[i]
end

for i = 1, #Config.FlameSizes do
    sizeById[Config.FlameSizes[i].id] = Config.FlameSizes[i]
end

for i = 1, #Config.EngineSounds do
    engineSoundById[Config.EngineSounds[i].id] = Config.EngineSounds[i]
end

for i = 1, #Config.BlockedModels do
    blockedModels[joaat(Config.BlockedModels[i])] = true
end

local function trimPlate(value)
    if type(value) ~= 'string' then return nil end
    return value:match('^%s*(.-)%s*$'):upper()
end

local function notify(description, notifyType)
    lib.notify({
        title = 'Backfire Lab',
        description = description,
        type = notifyType or 'inform',
        position = 'top-right'
    })
end

local function isSupportedVehicle(vehicle)
    if vehicle == 0 or not DoesEntityExist(vehicle) then
        return false, 'Nie znaleziono pojazdu.'
    end

    if Config.BlockedVehicleClasses[GetVehicleClass(vehicle)] then
        return false, 'Ten typ pojazdu nie obsługuje backfire.'
    end

    if blockedModels[GetEntityModel(vehicle)] then
        return false, 'Ten model nie obsługuje backfire.'
    end

    return true
end

local function getDriverVehicle(requireStopped)
    local ped = PlayerPedId()
    local vehicle = GetVehiclePedIsIn(ped, false)

    if vehicle == 0 then
        return nil, 'Musisz siedzieć w pojeździe.'
    end

    if Config.RequireDriverSeat and GetPedInVehicleSeat(vehicle, -1) ~= ped then
        return nil, 'Musisz siedzieć na miejscu kierowcy.'
    end

    local supported, reason = isSupportedVehicle(vehicle)
    if not supported then
        return nil, reason
    end

    if requireStopped and GetEntitySpeed(vehicle) > Config.MaxPurchaseSpeed then
        return nil, 'Zatrzymaj pojazd przed otwarciem tabletu.'
    end

    return {
        entity = vehicle,
        netId = VehToNet(vehicle),
        plate = trimPlate(GetVehicleNumberPlateText(vehicle)),
        model = GetEntityModel(vehicle)
    }
end

local function vehicleLabel(vehicle)
    local displayName = GetDisplayNameFromVehicleModel(GetEntityModel(vehicle))
    local label = GetLabelText(displayName)

    if not label or label == 'NULL' then
        return displayName
    end

    return label
end

local function publicCatalog()
    local frequencies = {}
    local colors = {}
    local sounds = {}
    local sizes = {}
    local engineSounds = {}

    for i = 1, #Config.Frequencies do
        local option = Config.Frequencies[i]
        frequencies[#frequencies + 1] = {
            id = option.id,
            label = option.label,
            description = option.description,
            price = option.price
        }
    end

    for i = 1, #Config.Colors do
        local option = Config.Colors[i]
        colors[#colors + 1] = {
            id = option.id,
            label = option.label,
            description = option.description,
            price = option.price,
            hex = option.hex
        }
    end

    for i = 1, #Config.Sounds do
        local option = Config.Sounds[i]
        sounds[#sounds + 1] = {
            id = option.id,
            label = option.label,
            description = option.description,
            price = option.price
        }
    end

    for i = 1, #Config.FlameSizes do
        local option = Config.FlameSizes[i]
        sizes[#sizes + 1] = {
            id = option.id,
            label = option.label,
            description = option.description,
            price = option.price,
            previewScale = option.previewScale
        }
    end

    for i = 1, #Config.EngineSounds do
        local option = Config.EngineSounds[i]
        engineSounds[#engineSounds + 1] = {
            id = option.id,
            label = option.label,
            description = option.description,
            category = option.category,
            price = option.price
        }
    end

    return {
        frequencies = frequencies,
        colors = colors,
        sounds = sounds,
        sizes = sizes,
        engineSounds = engineSounds
    }
end

local function closeTablet()
    if not uiOpen then return end

    uiOpen = false
    SetNuiFocus(false, false)
    SetNuiFocusKeepInput(false)
    SendNUIMessage({ action = 'close' })
end

local function openTablet()
    if uiOpen then return end

    local vehicle, reason = getDriverVehicle(true)
    if not vehicle then
        notify(reason, 'error')
        return
    end

    local response = lib.callback.await('kr_backfire:getVehicleData', false, {
        netId = vehicle.netId,
        plate = vehicle.plate
    })

    if not response or not response.ok then
        notify(response and response.message or 'Nie udało się połączyć z tabletem.', 'error')
        return
    end

    uiOpen = true
    SetNuiFocus(true, true)
    SetNuiFocusKeepInput(false)

    SendNUIMessage({
        action = 'open',
        payload = {
            vehicle = {
                label = vehicleLabel(vehicle.entity),
                plate = vehicle.plate,
                netId = vehicle.netId
            },
            installed = response.installed,
            settings = response.settings,
            balance = response.balance,
            installPrice = Config.InstallPrice,
            currency = Config.Currency,
            engineAudioAvailable = response.engineAudioAvailable == true,
            engineAudioResource = Config.EngineAudio.resource,
            catalog = publicCatalog(),
            defaults = Config.DefaultSelection
        }
    })
end

exports('openTablet', function(data)
    if not data then
        openTablet()
        return
    end

    exports.ox_inventory:useItem(data, function(usedData)
        if usedData then
            openTablet()
        end
    end)
end)

RegisterNetEvent('kr_backfire:client:openTablet', openTablet)

if Config.EnableTestCommand then
    RegisterCommand(Config.TestCommand, openTablet, false)
end

RegisterNUICallback('close', function(_, cb)
    closeTablet()
    cb({ ok = true })
end)

RegisterNUICallback('purchase', function(data, cb)
    local vehicle, reason = getDriverVehicle(true)
    if not vehicle then
        cb({ ok = false, message = reason })
        return
    end

    if trimPlate(data.plate) ~= vehicle.plate or tonumber(data.netId) ~= vehicle.netId then
        cb({ ok = false, message = 'Pojazd przy tablecie zmienił się.' })
        return
    end

    local response = lib.callback.await('kr_backfire:purchase', false, {
        netId = vehicle.netId,
        plate = vehicle.plate,
        frequency = data.frequency,
        color = data.color,
        sound = tostring(data.sound),
        size = data.size,
        engineSound = data.engineSound,
        shotVolume = data.shotVolume
    })

    if response and response.ok then
        runtime.vehicle = vehicle.entity
        runtime.netId = vehicle.netId
        runtime.plate = vehicle.plate
        runtime.settings = response.settings
        if applyEngineSound then
            applyEngineSound(vehicle.entity, response.settings.engineSound)
        end
        notify(response.message, 'success')
    else
        notify(response and response.message or 'Zakup nie powiódł się.', 'error')
    end

    cb(response or { ok = false, message = 'Brak odpowiedzi serwera.' })
end)

RegisterNUICallback('toggle', function(data, cb)
    local vehicle, reason = getDriverVehicle(true)
    if not vehicle then
        cb({ ok = false, message = reason })
        return
    end

    if trimPlate(data.plate) ~= vehicle.plate or tonumber(data.netId) ~= vehicle.netId then
        cb({ ok = false, message = 'Pojazd przy tablecie zmienił się.' })
        return
    end

    local response = lib.callback.await('kr_backfire:toggle', false, {
        netId = vehicle.netId,
        plate = vehicle.plate,
        enabled = data.enabled == true
    })

    if response and response.ok then
        runtime.settings = response.settings
        notify(response.message, 'success')
    else
        notify(response and response.message or 'Nie udało się zmienić stanu.', 'error')
    end

    cb(response or { ok = false, message = 'Brak odpowiedzi serwera.' })
end)

RegisterNUICallback('previewSound', function(data, cb)
    local sound = soundById[tostring(data.sound)]
    if sound then
        local shotVolume = math.max(0.0, math.min(1.0, tonumber(data.shotVolume) or 1.0))
        SendNUIMessage({
            action = 'playSound',
            sound = sound.id,
            volume = 0.55 * shotVolume
        })
    end
    cb({ ok = sound ~= nil })
end)

local function engineAudioAvailable()
    return GetResourceState(Config.EngineAudio.resource) == 'started'
        and GetGameTimer() >= engineAudioReadyAt
end

local function hasEngineBank(soundId)
    if engineBankAvailable[soundId] ~= nil then
        return engineBankAvailable[soundId]
    end

    local resource = Config.EngineAudio.resource
    local prefix = ('audioconfig/%s'):format(soundId)
    local hasGameData = LoadResourceFile(resource, ('%s_game.dat151.rel'):format(prefix)) ~= nil
    local hasSoundData = LoadResourceFile(resource, ('%s_sounds.dat54.rel'):format(prefix)) ~= nil
    local available = hasGameData and hasSoundData

    engineBankAvailable[soundId] = available

    if not available and not engineBankWarned[soundId] then
        engineBankWarned[soundId] = true
        print(('[kr_backfire] Brak kompletnego banku silnika %s w %s. Nie przypisano go, aby nie wyciszyć pojazdu.'):format(
            soundId,
            resource
        ))
    end

    return available
end

applyEngineSound = function(vehicle, soundId)
    if vehicle == 0 or not DoesEntityExist(vehicle) or not engineAudioAvailable() then
        return false
    end

    local option = engineSoundById[soundId]
    if not option or not hasEngineBank(soundId) then return false end

    -- Entity handles are reusable. Include the vehicle identity to prevent a
    -- stale entry from suppressing audio on a newly streamed vehicle.
    local netId = VehToNet(vehicle)
    local model = GetEntityModel(vehicle)
    local plate = trimPlate(GetVehicleNumberPlateText(vehicle))
    local previous = engineAppliedByVehicle[vehicle]

    if previous
        and previous.soundId == soundId
        and previous.netId == netId
        and previous.model == model
        and previous.plate == plate
    then
        return true
    end

    -- A legitimate engine-audio swap can change GTA's built-in radio once.
    -- Only preserve the local player's station; never override other players.
    local isPlayerVehicle = GetVehiclePedIsIn(PlayerPedId(), false) == vehicle
    local radioStation = isPlayerVehicle and GetPlayerRadioStationName() or nil
    if isPlayerVehicle and (not radioStation or radioStation == '') then
        radioStation = 'OFF'
    end

    -- Wywołanie po hashu działa również na buildach, które udostępniają ten
    -- native pod nowszą nazwą ForceUseAudioGameObject.
    Citizen.InvokeNative(0x4F0C413926060B38, vehicle, option.audioNameHash)
    engineAppliedByVehicle[vehicle] = {
        soundId = soundId,
        netId = netId,
        model = model,
        plate = plate
    }

    if radioStation
        and GetVehiclePedIsIn(PlayerPedId(), false) == vehicle
        and GetPlayerRadioStationName() ~= radioStation
    then
        SetRadioToStationName(radioStation)
    end

    return true
end

AddStateBagChangeHandler('kr_backfire', nil, function(bagName, _, value)
    if type(value) ~= 'table' or not value.engineSound then return end

    SetTimeout(0, function()
        local vehicle = GetEntityFromStateBagName(bagName)
        if vehicle ~= 0 and DoesEntityExist(vehicle) then
            applyEngineSound(vehicle, value.engineSound)
        end
    end)
end)

local DRAW_TEXTURED_POLY = 0x29280002282F1928
local DRAW_LIGHT_WITH_RANGE = 0xF2A1B2771A01DBD4
local USE_PARTICLE_FX_ASSET = 0x6C38AF3693A69A91
local START_PARTICLE_FX_LOOPED_ON_ENTITY = 0x1AE42C1660FD6517
local START_PARTICLE_FX_LOOPED_ON_ENTITY_BONE = 0xC6EB449E33977F0B
local SET_PARTICLE_FX_LOOPED_COLOUR = 0x7F8F65877F88783B
local SET_PARTICLE_FX_LOOPED_SCALE = 0xB44250AAA456492D
local STOP_PARTICLE_FX_LOOPED = 0x8F75998877616996

local function loadFlameTexture()
    if not Config.FlameOverlay.enabled then return false end
    if flameTextureReady then return true end
    if flameTextureAttempted then return false end

    flameTextureAttempted = true

    local txdOk, runtimeTxd = pcall(
        CreateRuntimeTxd,
        Config.FlameOverlay.textureDictionary
    )
    local textureOk, runtimeTexture = false, nil

    if txdOk and runtimeTxd then
        textureOk, runtimeTexture = pcall(
            CreateRuntimeTextureFromImage,
            runtimeTxd,
            Config.FlameOverlay.textureName,
            Config.FlameOverlay.textureFile
        )
    end

    flameTextureReady = txdOk
        and textureOk
        and runtimeTxd ~= nil
        and runtimeTexture ~= nil
        and runtimeTexture ~= 0

    if not flameTextureReady and not flameTextureWarned then
        flameTextureWarned = true
        print(('[kr_backfire] Nie udało się utworzyć tekstury %s. Płomień będzie niewidoczny.'):format(
            Config.FlameOverlay.textureFile
        ))
    end

    return flameTextureReady
end

local function offsetPoint(origin, firstVector, firstScale, secondVector, secondScale)
    return vector3(
        origin.x + (firstVector.x * firstScale) + (secondVector.x * secondScale),
        origin.y + (firstVector.y * firstScale) + (secondVector.y * secondScale),
        origin.z + (firstVector.z * firstScale) + (secondVector.z * secondScale)
    )
end

local function drawFlameTriangle(first, second, third, red, green, blue, alpha, uv)
    Citizen.InvokeNative(
        DRAW_TEXTURED_POLY,
        first.x,
        first.y,
        first.z,
        second.x,
        second.y,
        second.z,
        third.x,
        third.y,
        third.z,
        red,
        green,
        blue,
        alpha,
        Config.FlameOverlay.textureDictionary,
        Config.FlameOverlay.textureName,
        uv[1],
        uv[2],
        0.0,
        uv[3],
        uv[4],
        0.0,
        uv[5],
        uv[6],
        0.0
    )
end

local function drawFlamePlane(anchor, backwards, side, length, width, red, green, blue, alpha)
    local halfWidth = width * 0.5
    local rootLeft = offsetPoint(anchor, side, -halfWidth, backwards, 0.02)
    local rootRight = offsetPoint(anchor, side, halfWidth, backwards, 0.02)
    local tipCenter = offsetPoint(anchor, backwards, length, side, 0.0)
    local tipLeft = offsetPoint(tipCenter, side, -halfWidth, backwards, 0.0)
    local tipRight = offsetPoint(tipCenter, side, halfWidth, backwards, 0.0)

    -- Tekstura ma dyszę po prawej stronie (U=1) i wygasa w stronę końcówki
    -- (U=0). Każdy trójkąt jest rysowany w obu kierunkach, aby płomień był
    -- widoczny niezależnie od ustawienia kamery.
    drawFlameTriangle(rootLeft, rootRight, tipRight, red, green, blue, alpha, {
        1.0, 0.0, 1.0, 1.0, 0.0, 1.0
    })
    drawFlameTriangle(rootLeft, tipRight, tipLeft, red, green, blue, alpha, {
        1.0, 0.0, 0.0, 1.0, 0.0, 0.0
    })
    drawFlameTriangle(rootLeft, tipRight, rootRight, red, green, blue, alpha, {
        1.0, 0.0, 0.0, 1.0, 1.0, 1.0
    })
    drawFlameTriangle(rootLeft, tipLeft, tipRight, red, green, blue, alpha, {
        1.0, 0.0, 0.0, 0.0, 0.0, 1.0
    })
end

local function findExhaustBones(vehicle)
    local result = {}
    local seen = {}

    for i = 1, #Config.FlameOverlay.bones do
        local boneIndex = GetEntityBoneIndexByName(vehicle, Config.FlameOverlay.bones[i])

        if boneIndex ~= -1 and not seen[boneIndex] then
            seen[boneIndex] = true
            result[#result + 1] = boneIndex

            if #result >= Config.FlameOverlay.maxExhausts then
                break
            end
        end
    end

    -- Część addonów nie ma nazwanej kości wydechu. Wtedy dokładamy jeden
    -- punkt awaryjny przy tylnej, dolnej krawędzi modelu.
    if #result == 0 and Config.FlameOverlay.fallbackWhenNoBone then
        result[1] = -2
    end

    return result
end

local function getFlameAnchor(vehicle, boneIndex)
    if boneIndex ~= -2 then
        return GetWorldPositionOfEntityBone(vehicle, boneIndex)
    end

    local modelMin, _ = GetModelDimensions(GetEntityModel(vehicle))
    return GetOffsetFromEntityInWorldCoords(
        vehicle,
        0.0,
        modelMin.y - 0.05,
        modelMin.z + 0.32
    )
end

local function clamp01(value)
    return math.max(0.0, math.min(1.0, tonumber(value) or 0.0))
end

local function particleFxResourceReady()
    return Config.ParticleFx.enabled
        and GetResourceState(Config.ParticleFx.resource) == 'started'
end

local function requestParticleAsset(asset)
    if not particleFxResourceReady() then
        if not ptfxAssetWarned.resource then
            ptfxAssetWarned.resource = true
            print(('[kr_backfire] Zasób %s nie jest uruchomiony. Używam renderera awaryjnego.'):format(
                Config.ParticleFx.resource
            ))
        end
        return false
    end

    if HasNamedPtfxAssetLoaded(asset) then
        return true
    end

    if not ptfxAssetRequestedAt[asset] then
        ptfxAssetRequestedAt[asset] = GetGameTimer()
        RequestNamedPtfxAsset(asset)
    end

    if GetGameTimer() - ptfxAssetRequestedAt[asset] >= Config.ParticleFx.loadTimeout
        and not ptfxAssetWarned[asset]
    then
        ptfxAssetWarned[asset] = true
        print(('[kr_backfire] Asset PTFX %s nie załadował się w czasie. Używam renderera awaryjnego.'):format(
            asset
        ))
    end

    return false
end

local function preloadParticleAssets()
    if not particleFxResourceReady() then
        requestParticleAsset(Config.ParticleFx.backfire.asset)
        return
    end

    local assets = {
        Config.ParticleFx.backfire.asset,
        Config.ParticleFx.launch.asset
    }

    for i = 1, #assets do
        requestParticleAsset(assets[i])
    end

    local endAt = GetGameTimer() + Config.ParticleFx.loadTimeout
    while GetGameTimer() < endAt do
        local ready = true

        for i = 1, #assets do
            if not requestParticleAsset(assets[i]) then
                ready = false
            end
        end

        if ready then
            print(('[kr_backfire] PTFX v1.8.0 aktywne: %s + %s'):format(
                Config.ParticleFx.backfire.asset,
                Config.ParticleFx.launch.asset
            ))
            return
        end
        Wait(Config.ParticleFx.loadPollInterval)
    end
end

local function stopParticleHandles(handles)
    if type(handles) ~= 'table' then return end

    for i = 1, #handles do
        local handle = handles[i]
        if handle and handle ~= 0 then
            Citizen.InvokeNative(STOP_PARTICLE_FX_LOOPED, handle, false)
        end
    end
end

local function startParticleOnExhaust(asset, effect, vehicle, boneIndex, scale, rgb)
    Citizen.InvokeNative(USE_PARTICLE_FX_ASSET, asset)

    local ok, handle = pcall(function()
        if boneIndex == -2 then
            local modelMin, _ = GetModelDimensions(GetEntityModel(vehicle))
            return Citizen.InvokeNative(
                START_PARTICLE_FX_LOOPED_ON_ENTITY,
                effect,
                vehicle,
                0.0,
                modelMin.y - 0.05,
                modelMin.z + 0.32,
                0.0,
                0.0,
                0.0,
                scale,
                false,
                false,
                false,
                Citizen.ResultAsInteger()
            )
        end

        return Citizen.InvokeNative(
            START_PARTICLE_FX_LOOPED_ON_ENTITY_BONE,
            effect,
            vehicle,
            0.0,
            0.0,
            0.0,
            0.0,
            0.0,
            0.0,
            boneIndex,
            scale,
            false,
            false,
            false,
            Citizen.ResultAsInteger()
        )
    end)

    if not ok or not handle or handle == 0 then
        return nil
    end

    Citizen.InvokeNative(
        SET_PARTICLE_FX_LOOPED_COLOUR,
        handle,
        clamp01(rgb[1]),
        clamp01(rgb[2]),
        clamp01(rgb[3]),
        true
    )
    Citizen.InvokeNative(SET_PARTICLE_FX_LOOPED_SCALE, handle, scale)

    return handle
end

local function playNativeParticle(vehicle, exhaustBones, color, size, launch)
    if not particleFxResourceReady() or #exhaustBones == 0 then return false end

    local profile = launch and Config.ParticleFx.launch or Config.ParticleFx.backfire
    if not requestParticleAsset(profile.asset) then return false end

    local scale = launch
        and tonumber(size.nitroScale)
        or tonumber(size.backfireScale)
    scale = math.max(0.05, scale or tonumber(size.previewScale) or 1.0)

    local duration = tonumber(size.duration) or Config.FlameOverlay.defaultDuration
    if launch then
        duration = duration * Config.LaunchControl.durationMultiplier
    end
    duration = math.max(tonumber(profile.minimumDuration) or 1, duration)

    local rgb = color.rgb or { 1.0, 1.0, 1.0 }
    local now = GetGameTimer()
    local existing = activePtfxByVehicle[vehicle]

    if launch
        and existing
        and existing.launch
        and existing.asset == profile.asset
        and existing.effect == profile.effect
        and math.abs(existing.scale - scale) < 0.001
        and math.abs(existing.red - clamp01(rgb[1])) < 0.001
        and math.abs(existing.green - clamp01(rgb[2])) < 0.001
        and math.abs(existing.blue - clamp01(rgb[3])) < 0.001
    then
        existing.expiresAt = now + duration
        return true
    end

    if existing then
        activePtfxByVehicle[vehicle] = nil
        stopParticleHandles(existing.handles)
    end

    local handles = {}
    for i = 1, #exhaustBones do
        local handle = startParticleOnExhaust(
            profile.asset,
            profile.effect,
            vehicle,
            exhaustBones[i],
            scale,
            rgb
        )

        if handle then
            handles[#handles + 1] = handle
        end
    end

    if #handles == 0 then
        local warningKey = ('%s:%s'):format(profile.asset, profile.effect)
        if not ptfxAssetWarned[warningKey] then
            ptfxAssetWarned[warningKey] = true
            print(('[kr_backfire] Nie udało się uruchomić efektu %s/%s. Używam renderera awaryjnego.'):format(
                profile.asset,
                profile.effect
            ))
        end
        return false
    end

    local entry = {
        handles = handles,
        launch = launch,
        asset = profile.asset,
        effect = profile.effect,
        scale = scale,
        red = clamp01(rgb[1]),
        green = clamp01(rgb[2]),
        blue = clamp01(rgb[3]),
        expiresAt = now + duration
    }
    activePtfxByVehicle[vehicle] = entry

    CreateThread(function()
        while activePtfxByVehicle[vehicle] == entry
            and DoesEntityExist(vehicle)
            and GetGameTimer() < entry.expiresAt
        do
            Wait(15)
        end

        if activePtfxByVehicle[vehicle] == entry then
            activePtfxByVehicle[vehicle] = nil
            stopParticleHandles(entry.handles)
        end
    end)

    return true
end

local function drawScalableFlames(vehicle, exhaustBones, color, size, launch)
    if not flameTextureReady or #exhaustBones == 0 then return end

    -- GetEntityMatrix zwraca kolejno: forward, right, up, position.
    -- Zamiana dwóch pierwszych wektorów powodowała, że płomień leciał w bok.
    local forward, right, up, _ = GetEntityMatrix(vehicle)
    local backwards = vector3(-forward.x, -forward.y, -forward.z)
    local lengthMultiplier = launch and Config.LaunchControl.flameLengthMultiplier or 1.0
    local widthMultiplier = launch and Config.LaunchControl.flameWidthMultiplier or 1.0
    local phase = GetGameTimer() * 0.055
    local flicker = 1.0 + (math.sin(phase) * 0.055) + (math.sin(phase * 0.43) * 0.025)
    local length = math.max(0.05, (tonumber(size.length) or 0.5) * lengthMultiplier * flicker)
    local width = math.max(0.04, (tonumber(size.width) or 0.16) * widthMultiplier)
    local rgb = color.rgb or { 1.0, 1.0, 1.0 }
    local red = math.floor(math.max(0.0, math.min(1.0, rgb[1] or 1.0)) * 255.0)
    local green = math.floor(math.max(0.0, math.min(1.0, rgb[2] or 1.0)) * 255.0)
    local blue = math.floor(math.max(0.0, math.min(1.0, rgb[3] or 1.0)) * 255.0)
    local alpha = math.floor(math.max(0, math.min(255, Config.FlameOverlay.alpha)))
    local coreMix = math.max(0.0, math.min(1.0, Config.FlameOverlay.coreWhiteMix))
    local coreRed = math.floor(red + ((255 - red) * coreMix))
    local coreGreen = math.floor(green + ((255 - green) * coreMix))
    local coreBlue = math.floor(blue + ((255 - blue) * coreMix))
    local coreAlpha = math.floor(math.max(0, math.min(255, Config.FlameOverlay.coreAlpha)))
    local coreLength = length * Config.FlameOverlay.coreLengthMultiplier
    local coreWidth = width * Config.FlameOverlay.coreWidthMultiplier
    local glowScale = math.max(0.65, tonumber(size.previewScale) or 1.0)

    for i = 1, #exhaustBones do
        local anchor = getFlameAnchor(vehicle, exhaustBones[i])

        -- Zewnętrzny, poszarpany płomień w pełnym kolorze wybranym w
        -- tablecie.
        drawFlamePlane(anchor, backwards, right, length, width, red, green, blue, alpha)
        drawFlamePlane(anchor, backwards, up, length, width * 0.82, red, green, blue, alpha)

        -- Krótszy biało-gorący rdzeń zachowuje kolor profilu, ale dodaje
        -- naturalną głębię bez stałej niebieskiej warstwy YPT.
        drawFlamePlane(
            anchor,
            backwards,
            right,
            coreLength,
            coreWidth,
            coreRed,
            coreGreen,
            coreBlue,
            coreAlpha
        )
        drawFlamePlane(
            anchor,
            backwards,
            up,
            coreLength,
            coreWidth * 0.82,
            coreRed,
            coreGreen,
            coreBlue,
            coreAlpha
        )

        Citizen.InvokeNative(
            DRAW_LIGHT_WITH_RANGE,
            anchor.x,
            anchor.y,
            anchor.z,
            red,
            green,
            blue,
            Config.FlameOverlay.glowRange * glowScale,
            Config.FlameOverlay.glowIntensity
        )
    end
end

local function stopAllFlamePulses()
    nitroPulseTokenByVehicle = {}

    for vehicle, entry in pairs(activePtfxByVehicle) do
        activePtfxByVehicle[vehicle] = nil
        stopParticleHandles(entry.handles)
    end
end

local function playFlame(vehicle, colorId, sizeId, launch)
    local color = colorById[colorId] or colorById[Config.DefaultSelection.color]
    local size = sizeById[sizeId] or sizeById[Config.DefaultSelection.size]
    if not color or not size then return end

    local exhaustBones = findExhaustBones(vehicle)
    if playNativeParticle(vehicle, exhaustBones, color, size, launch) then
        return
    end

    loadFlameTexture()

    local duration = tonumber(size.duration) or Config.FlameOverlay.defaultDuration
    if launch then
        duration = duration * Config.LaunchControl.durationMultiplier
    end
    duration = math.max(1, math.floor(duration))

    -- Każdy nowy strzał zastępuje poprzedni token. Starszy wątek kończy się
    -- bez wyłączenia efektu, więc szybka seria nie gasi następnego płomienia.
    local token = (nitroPulseTokenByVehicle[vehicle] or 0) + 1
    nitroPulseTokenByVehicle[vehicle] = token

    CreateThread(function()
        local endAt = GetGameTimer() + duration

        while DoesEntityExist(vehicle)
            and nitroPulseTokenByVehicle[vehicle] == token
            and GetGameTimer() < endAt
        do
            -- Awaryjny renderer nadal korzysta wyłącznie z koloru wybranego
            -- w tablecie; nigdy nie dokłada stałej niebieskiej warstwy.
            drawScalableFlames(vehicle, exhaustBones, color, size, launch)
            Wait(0)
        end

        if nitroPulseTokenByVehicle[vehicle] == token then
            nitroPulseTokenByVehicle[vehicle] = nil
        end
    end)
end

RegisterNetEvent('kr_backfire:client:playShot', function(netId, settings)
    local vehicle = NetToVeh(netId)
    if vehicle == 0 or not DoesEntityExist(vehicle) or type(settings) ~= 'table' then return end

    local distance = #(GetEntityCoords(PlayerPedId()) - GetEntityCoords(vehicle))
    if distance > Config.SyncDistance then return end

    -- Shot events are for pops and flames only. Engine audio is assigned via
    -- the vehicle state bag / runtime refresh, never for every single shot.
    if settings.liftOff == true and Config.LiftOffSound.enabled then
        local maxDistance = math.min(Config.LiftOffSound.maxDistance, Config.SyncDistance)
        local shotVolume = math.max(0.0, math.min(1.0, tonumber(settings.shotVolume) or 1.0))

        if distance <= maxDistance then
            local ratio = 1.0 - (distance / maxDistance)
            local volume = math.max(
                0.0,
                math.min(1.0, ratio * ratio * Config.LiftOffSound.volume * shotVolume)
            )

            SendNUIMessage({
                action = 'playSound',
                sound = Config.LiftOffSound.file,
                volume = volume
            })
        end

        Wait(Config.LiftOffSound.popDelay)
    end

    if distance <= Config.AudioDistance and soundById[tostring(settings.sound)] then
        local ratio = 1.0 - (distance / Config.AudioDistance)
        local modeVolume = settings.launch == true and Config.LaunchControl.soundVolumeMultiplier or 1.0
        local shotVolume = math.max(0.0, math.min(1.0, tonumber(settings.shotVolume) or 1.0))
        local volume = math.max(
            0.0,
            math.min(1.0, ratio * ratio * Config.SoundVolume * modeVolume * shotVolume)
        )

        SendNUIMessage({
            action = 'playSound',
            sound = tostring(settings.sound),
            volume = volume
        })
    end

    -- Renderer płomienia jest uruchamiany po audio i nie blokuje strzału.
    playFlame(vehicle, settings.color, settings.size, settings.launch == true)
end)

local function resetRuntime()
    runtime.vehicle = 0
    runtime.netId = 0
    runtime.plate = nil
    runtime.settings = nil
    runtime.lastRelease = 0
    runtime.lastLaunch = 0
    runtime.previousThrottle = false
    runtime.peakRpm = 0.0
    runtime.loading = false
end

local function refreshRuntime(vehicle)
    if runtime.loading then return end
    runtime.loading = true

    local netId = VehToNet(vehicle)
    local plate = trimPlate(GetVehicleNumberPlateText(vehicle))
    local response = lib.callback.await('kr_backfire:getRuntimeSettings', false, {
        netId = netId,
        plate = plate
    })

    if response
        and response.ok
        and DoesEntityExist(vehicle)
        and GetVehiclePedIsIn(PlayerPedId(), false) == vehicle
    then
        runtime.vehicle = vehicle
        runtime.netId = netId
        runtime.plate = plate
        runtime.settings = response.settings

        if runtime.settings then
            applyEngineSound(vehicle, runtime.settings.engineSound)
        end
    else
        runtime.vehicle = 0
        runtime.settings = nil
    end

    runtime.loading = false
end

CreateThread(function()
    math.randomseed(GetGameTimer() + PlayerId())

    while true do
        local wait = 650
        local ped = PlayerPedId()
        local vehicle = GetVehiclePedIsIn(ped, false)
        local isDriver = vehicle ~= 0 and GetPedInVehicleSeat(vehicle, -1) == ped

        if not isDriver then
            if runtime.vehicle ~= 0 then
                resetRuntime()
            end
        else
            if runtime.vehicle ~= vehicle and not runtime.loading then
                refreshRuntime(vehicle)
            end

            local settings = runtime.settings
            local frequency = settings and settings.enabled and frequencyById[settings.frequency] or nil

            if frequency then
                wait = 25
                local throttle = GetControlNormal(0, 71) > 0.15 or IsControlPressed(0, 71)
                local released = runtime.previousThrottle and not throttle
                local rpm = GetVehicleCurrentRpm(vehicle)
                local now = GetGameTimer()
                local handbrake = IsControlPressed(0, Config.LaunchControl.handbrakeControl)
                    or IsDisabledControlPressed(0, Config.LaunchControl.handbrakeControl)
                local launchActive = Config.LaunchControl.enabled
                    and throttle
                    and handbrake
                    and GetEntitySpeed(vehicle) <= Config.LaunchControl.maxSpeed
                    and GetIsVehicleEngineRunning(vehicle)
                    and not IsEntityInAir(vehicle)

                if launchActive
                    and rpm >= Config.LaunchControl.minRpm
                    and now - runtime.lastLaunch >= Config.LaunchControl.interval
                then
                    runtime.lastLaunch = now
                    TriggerServerEvent('kr_backfire:server:shot', runtime.netId, false, 'launch')
                end

                if throttle then
                    runtime.peakRpm = math.max(runtime.peakRpm, rpm)
                end

                if released
                    and GetIsVehicleEngineRunning(vehicle)
                    and not IsEntityInAir(vehicle)
                    and math.max(runtime.peakRpm, rpm) >= frequency.minRpm
                    and now - runtime.lastRelease >= frequency.cooldown
                then
                    runtime.lastRelease = now
                    local burstCount = 1

                    if math.random() <= frequency.chance then
                        burstCount = math.random(frequency.minBursts, frequency.maxBursts)
                    end

                    local expectedVehicle = vehicle
                    local expectedNetId = runtime.netId
                    local launchGap = now - runtime.lastLaunch
                    local initialDelay = runtime.lastLaunch > 0
                        and math.max(0, Config.Security.minShotInterval - launchGap + 5)
                        or 0

                    CreateThread(function()
                        if initialDelay > 0 then
                            Wait(initialDelay)
                        end

                        for i = 1, burstCount do
                            if GetVehiclePedIsIn(PlayerPedId(), false) ~= expectedVehicle
                                or runtime.netId ~= expectedNetId
                                or not runtime.settings
                                or runtime.settings.enabled ~= true
                            then
                                break
                            end
                            TriggerServerEvent('kr_backfire:server:shot', expectedNetId, i == 1)

                            if i < burstCount then
                                Wait(math.random(frequency.minGap, frequency.maxGap))
                            end
                        end
                    end)
                end

                if not throttle then
                    runtime.peakRpm = 0.0
                end

                runtime.previousThrottle = throttle
            else
                runtime.previousThrottle = false
                runtime.peakRpm = 0.0
            end
        end

        Wait(wait)
    end
end)

CreateThread(function()
    Wait(500)
    preloadParticleAssets()
    loadFlameTexture()

    while true do
        local settings = runtime.settings

        if runtime.vehicle ~= 0 and settings then
            -- Idempotent: this retry is harmless after the first application.
            applyEngineSound(runtime.vehicle, settings.engineSound)
        end

        for vehicle in pairs(engineAppliedByVehicle) do
            if not DoesEntityExist(vehicle) then
                engineAppliedByVehicle[vehicle] = nil
            end
        end

        Wait(Config.EngineAudio.retryInterval)
    end
end)

CreateThread(function()
    while true do
        if uiOpen then
            local vehicle = GetVehiclePedIsIn(PlayerPedId(), false)
            if vehicle == 0 or GetEntitySpeed(vehicle) > 3.0 then
                closeTablet()
                notify('Tablet został zamknięty, ponieważ pojazd ruszył.', 'error')
            end
            Wait(300)
        else
            Wait(1000)
        end
    end
end)

AddEventHandler('onResourceStop', function(resourceName)
    if resourceName ~= GetCurrentResourceName() then return end
    stopAllFlamePulses()
    SetNuiFocus(false, false)
    SetNuiFocusKeepInput(false)
end)

AddEventHandler('onClientResourceStart', function(resourceName)
    if resourceName == Config.ParticleFx.resource then
        ptfxAssetRequestedAt = {}
        ptfxAssetWarned = {}
        CreateThread(preloadParticleAssets)
    end

    if resourceName == Config.EngineAudio.resource then
        engineAudioReadyAt = GetGameTimer() + Config.EngineAudio.loadDelay
        engineAppliedByVehicle = {}
        engineBankAvailable = {}
        engineBankWarned = {}
    end
end)

AddEventHandler('onClientResourceStop', function(resourceName)
    if resourceName == Config.ParticleFx.resource then
        stopAllFlamePulses()
        ptfxAssetRequestedAt = {}
    end

    if resourceName ~= Config.EngineAudio.resource then return end
    engineAudioReadyAt = GetGameTimer() + Config.EngineAudio.loadDelay
    engineAppliedByVehicle = {}
    engineBankAvailable = {}
end)
