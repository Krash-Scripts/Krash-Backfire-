Config = {}

Config.ItemName = 'backfire_tablet'
Config.RequireTabletItem = true
Config.PaymentAccount = 'bank'
Config.Currency = '$'
Config.InstallPrice = 45000

-- Włącz tylko na czas testów. Produkcyjnie tablet powinien być otwierany przedmiotem.
Config.EnableTestCommand = false
Config.TestCommand = 'backfiretablet'

Config.RequireVehicleOwnerForPurchase = true
Config.RequireDriverSeat = true
Config.MaxPurchaseSpeed = 1.5

Config.OwnedVehicles = {
    table = 'owned_vehicles',
    plateColumn = 'plate',
    ownerColumn = 'owner'
}

Config.SyncDistance = 70.0
Config.AudioDistance = 42.0
Config.SoundVolume = 0.72

Config.EngineAudio = {
    -- Nazwa folderu zasobu pobranego z repozytorium SpiritsCreations.
    resource = 'Audio_Pack',
    price = 24000,
    requireResourceForPurchase = true,
    -- Banki AWC potrzebują chwili po starcie zasobu, zanim można bezpiecznie
    -- przypisać je do pojazdu. Zbyt wczesne przypisanie może wyciszyć silnik.
    loadDelay = 2500,
    retryInterval = 500
}

Config.LiftOffSound = {
    enabled = true,
    file = 'lift_off',
    volume = 0.46,
    maxDistance = 34.0,
    popDelay = 55
}

Config.Security = {
    purchaseCooldown = 1500,
    toggleCooldown = 750,
    minShotInterval = 60,
    minLiftOffInterval = 300,
    minLaunchInterval = 110
}

Config.BlockedVehicleClasses = {
    [8] = true,  -- motocykle
    [13] = true, -- rowery
    [14] = true, -- łodzie
    [15] = true, -- helikoptery
    [16] = true, -- samoloty
    [21] = true  -- pociągi
}

-- Nazwy modeli bez backfire, np. pojazdy elektryczne z Twojego serwera.
Config.BlockedModels = {
    'airtug',
    'caddy',
    'caddy2',
    'caddy3',
    'cyclone',
    'dilettante',
    'dilettante2',
    'imorgon',
    'iwagen',
    'khamelion',
    'neon',
    'omnisegt',
    'raiden',
    'surge',
    'tezeract',
    'voltic',
    'voltic2'
}

-- Główny renderer korzysta z natywnych efektów GTA, ale z punktowo
-- poprawionymi krzywymi RGB w `kr_backfire_fx`. Dzięki RGBCanTint ten sam
-- jakościowy efekt może otrzymać inny kolor na każdym pojeździe.
Config.ParticleFx = {
    enabled = true,
    resource = 'kr_backfire_fx',
    backfire = {
        asset = 'krbf_core',
        effect = 'veh_backfire',
        minimumDuration = 70
    },
    launch = {
        asset = 'krbf_nitro',
        effect = 'veh_nitrous',
        -- Kolejne impulsy W + Spacja przedłużają ten sam efekt zamiast
        -- nakładać kilka identycznych warstw.
        minimumDuration = 230
    },
    loadTimeout = 5000,
    loadPollInterval = 50
}

-- Awaryjny renderer teksturowany uruchamia się wyłącznie wtedy, gdy natywny
-- asset YPT nie zdążył się załadować. Kości wydechu są wspólne dla obu
-- rendererów.
Config.FlameOverlay = {
    enabled = true,
    textureDictionary = 'kr_backfire_runtime',
    textureName = 'nitro_flame',
    textureFile = 'textures/nitro_flame.png',
    defaultDuration = 80,
    -- Zewnętrzna kolorowana warstwa.
    alpha = 150,
    -- Krótszy, jaśniejszy rdzeń mieszany z bielą.
    coreAlpha = 105,
    coreLengthMultiplier = 1.62,
    coreWidthMultiplier = 1.46,
    coreWhiteMix = 0.58,
    -- Subtelne dynamiczne światło w kolorze wybranego płomienia.
    glowRange = 1.1,
    glowIntensity = 0.72,
    maxExhausts = 8,
    fallbackWhenNoBone = true,
    bones = {
        'exhaust',
        'exhaust_2',
        'exhaust_3',
        'exhaust_4',
        'exhaust_5',
        'exhaust_6',
        'exhaust_7',
        'exhaust_8',
        'exhaust_9',
        'exhaust_10',
        'exhaust_11',
        'exhaust_12',
        'exhaust_13',
        'exhaust_14',
        'exhaust_15',
        'exhaust_16'
    }
}

-- W + Spacja na postoju uruchamia mocniejszy tryb launch-control.
Config.LaunchControl = {
    enabled = true,
    handbrakeControl = 76,
    maxSpeed = 1.5,
    minRpm = 0.60,
    interval = 145,
    durationMultiplier = 1.45,
    flameLengthMultiplier = 2.35,
    flameWidthMultiplier = 1.15,
    soundVolumeMultiplier = 1.12
}

Config.DefaultSelection = {
    frequency = 'street',
    color = 'green',
    sound = '2',
    size = 'street',
    engineSound = 'lg57mustangtv8',
    shotVolume = 1.0
}

Config.Frequencies = {
    {
        id = 'subtle',
        label = 'Subtelny',
        description = 'Pojedyncze, spokojne strzały przy odpuszczeniu gazu.',
        price = 9000,
        minRpm = 0.70,
        chance = 0.46,
        cooldown = 1050,
        minBursts = 1,
        maxBursts = 2,
        minGap = 130,
        maxGap = 210
    },
    {
        id = 'street',
        label = 'Street',
        description = 'Wyraźny backfire do codziennej jazdy po mieście.',
        price = 17000,
        minRpm = 0.64,
        chance = 0.72,
        cooldown = 660,
        minBursts = 2,
        maxBursts = 3,
        minGap = 100,
        maxGap = 165
    },
    {
        id = 'race',
        label = 'Race',
        description = 'Agresywna seria przeznaczona do mocnych projektów.',
        price = 30000,
        minRpm = 0.58,
        chance = 0.94,
        cooldown = 420,
        minBursts = 3,
        maxBursts = 5,
        minGap = 75,
        maxGap = 125
    }
}

-- `hex` odpowiada za próbkę w tablecie, a `rgb` za barwę płomienia w grze.
-- Każda wartość RGB mieści się w zakresie 0.0–1.0.
Config.Colors = {
    {
        id = 'classic',
        label = 'Klasyczny',
        description = 'Naturalny pomarańczowy płomień.',
        price = 0,
        hex = '#ff6a16',
        rgb = { 1.0, 0.26, 0.02 }
    },
    {
        id = 'green',
        label = 'KR Green',
        description = 'Soczysta zieleń zgodna z motywem serwera.',
        price = 12500,
        hex = '#66ff00',
        rgb = { 0.2, 1.0, 0.02 }
    },
    {
        id = 'blue',
        label = 'Blue Heat',
        description = 'Chłodny, niebieski płomień.',
        price = 12500,
        hex = '#3d8bff',
        rgb = { 0.1, 0.4, 1.0 }
    },
    {
        id = 'violet',
        label = 'Ultraviolet',
        description = 'Fioletowy efekt do aut pokazowych.',
        price = 14500,
        hex = '#9b5cff',
        rgb = { 0.6, 0.15, 1.0 }
    },
    {
        id = 'pink',
        label = 'Hot Pink',
        description = 'Mocny różowy akcent.',
        price = 14500,
        hex = '#ff4faa',
        rgb = { 1.0, 0.16, 0.58 }
    },
    {
        id = 'white',
        label = 'White Flash',
        description = 'Jasny, niemal biały błysk.',
        price = 18000,
        hex = '#eafff4',
        rgb = { 0.9, 1.0, 1.0 }
    }
}

Config.FlameSizes = {
    {
        id = 'compact',
        label = 'Street Compact',
        description = 'Krótki płomień do dyskretnej jazdy miejskiej.',
        price = 6000,
        duration = 50,
        length = 0.28,
        width = 0.11,
        backfireScale = 0.52,
        nitroScale = 0.78,
        previewScale = 0.78
    },
    {
        id = 'street',
        label = 'Street Burst',
        description = 'Wyraźny, dobrze widoczny płomień.',
        price = 12000,
        duration = 80,
        length = 0.50,
        width = 0.16,
        backfireScale = 0.70,
        nitroScale = 1.00,
        previewScale = 1.0
    },
    {
        id = 'track',
        label = 'Track Flame',
        description = 'Długi płomień do mocnych projektów.',
        price = 21000,
        duration = 115,
        length = 0.78,
        width = 0.22,
        backfireScale = 0.90,
        nitroScale = 1.24,
        previewScale = 1.22
    },
    {
        id = 'afterburner',
        label = 'Afterburner',
        description = 'Największy efekt pokazowy; na W + Spacja robi się jeszcze mocniejszy.',
        price = 34000,
        duration = 155,
        length = 2.08,
        width = 0.30,
        backfireScale = 1.12,
        nitroScale = 2.52,
        previewScale = 1.45
    }
}

Config.Sounds = {
    {
        id = '1',
        label = 'Raw Pop',
        description = 'Krótki, suchy strzał.',
        price = 5000
    },
    {
        id = '2',
        label = 'Street Crack',
        description = 'Głośny i wyraźny trzask.',
        price = 8000
    },
    {
        id = '3',
        label = 'Deep Bang',
        description = 'Niższy, cięższy dźwięk.',
        price = 10000
    },
    {
        id = '4',
        label = 'Sharp Snap',
        description = 'Szybki, metaliczny snap.',
        price = 10000
    },
    {
        id = '5',
        label = 'Race Burst',
        description = 'Ostry dźwięk torowego wydechu.',
        price = 14000
    },
    {
        id = '6',
        label = 'Heavy Cannon',
        description = 'Najmocniejszy wariant w zestawie.',
        price = 18000
    }
}
