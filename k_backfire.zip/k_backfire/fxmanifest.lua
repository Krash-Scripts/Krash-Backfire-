fx_version 'cerulean'
game 'gta5'

author 'KR4SH'
description 'Vehicle backfire tablet for ESX, ox_inventory and ox_lib'
version '1.8.1'

lua54 'yes'

shared_scripts {
    '@ox_lib/init.lua',
    'config.lua',
    'engine_sounds.lua'
}

client_scripts {
    'client/main.lua'
}

server_scripts {
    '@oxmysql/lib/MySQL.lua',
    'server/main.lua'
}

ui_page 'web/index.html'

files {
    'web/index.html',
    'web/style.css',
    'web/app.js',
    'web/sounds/*.ogg',
    'textures/nitro_flame.png'
}

dependencies {
    'kr_backfire_fx',
    'es_extended',
    'ox_lib',
    'ox_inventory',
    'oxmysql'
}
