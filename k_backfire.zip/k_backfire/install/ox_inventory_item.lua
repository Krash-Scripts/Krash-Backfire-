-- Skopiuj wpis znajdujący się wewnątrz tej tabeli do ox_inventory/data/items.lua.

return {
    ['backfire_tablet'] = {
        label = 'Tablet Backfire',
        weight = 650,
        stack = false,
        close = true,
        consume = 0,
        description = 'Tablet do konfiguracji układu backfire w pojeździe.',
        client = {
            export = 'kr_backfire.openTablet'
        }
    }
}
