local ESX = exports.es_extended:getSharedObject()

local frequencyById = {}
local colorById = {}
local soundById = {}
local sizeById = {}
local engineSoundById = {}
local blockedModels = {}
local settingsCache = {}
local activeBySource = {}
local purchaseLocks = {}
local actionTimes = {}
local shotTimes = {}
local liftOffTimes = {}
local playerGrid = {}
local schemaReady = false

for i = 1, #Config.Frequencies do
    frequencyById[Config.Frequencies[i].id] = Config.Frequencies[i]
end

for i = 1, #Config.Colors do
    colorById[Config.Colors[i].id] = Config.Colors[i]
end

for i = 1, #Config.Sounds do
    soundById[Config.Sounds[i].id] = Config.Sounds[i]
end

for i = 1, #Config.FlameSizes do
    sizeById[Config.FlameSizes[i].id] = Config.FlameSizes[i]
end

for i = 1, #Config.EngineSounds do
    engineSoundById[Config.EngineSounds[i].id] = Config.EngineSounds[i]
end

for i = 1, #Config.BlockedModels do
    blockedModels[joaat(Config.BlockedModels[i])] = true
end

local function engineAudioAvailable()
    return GetResourceState(Config.EngineAudio.resource) == 'started'
end

local function ensureColumn(column, definition)
    local exists = MySQL.scalar.await([[
        SELECT COUNT(*)
        FROM `INFORMATION_SCHEMA`.`COLUMNS`
        WHERE `TABLE_SCHEMA` = DATABASE()
          AND `TABLE_NAME` = 'kr_backfire_vehicles'
          AND `COLUMN_NAME` = ?
    ]], { column })

    if tonumber(exists) == 0 then
        MySQL.query.await(
            ('ALTER TABLE `kr_backfire_vehicles` ADD COLUMN `%s` %s'):format(column, definition)
        )
    end
end

CreateThread(function()
    local ok, errorMessage = pcall(function()
        MySQL.query.await([[
            CREATE TABLE IF NOT EXISTS `kr_backfire_vehicles` (
                `plate` VARCHAR(16) NOT NULL,
                `owner` VARCHAR(80) NOT NULL,
                `enabled` TINYINT(1) NOT NULL DEFAULT 1,
                `frequency` VARCHAR(24) NOT NULL DEFAULT 'street',
                `color` VARCHAR(24) NOT NULL DEFAULT 'green',
                `sound` VARCHAR(24) NOT NULL DEFAULT '2',
                `flame_size` VARCHAR(24) NOT NULL DEFAULT 'street',
                `engine_sound` VARCHAR(64) NOT NULL DEFAULT 'lg57mustangtv8',
                `shot_volume` DECIMAL(4,3) NOT NULL DEFAULT 1.000,
                `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
                `updated_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
                PRIMARY KEY (`plate`),
                KEY `idx_kr_backfire_owner` (`owner`)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
        ]])

        ensureColumn('flame_size', "VARCHAR(24) NOT NULL DEFAULT 'street' AFTER `sound`")
        ensureColumn('engine_sound', "VARCHAR(64) NOT NULL DEFAULT 'lg57mustangtv8' AFTER `flame_size`")
        ensureColumn('shot_volume', "DECIMAL(4,3) NOT NULL DEFAULT 1.000 AFTER `engine_sound`")
    end)

    if not ok then
        print(('[kr_backfire] Automatyczna migracja bazy nie powiodła się: %s'):format(errorMessage))
        return
    end

    schemaReady = true
end)

local function trimPlate(value)
    if type(value) ~= 'string' then return nil end
    local plate = value:match('^%s*(.-)%s*$'):upper()
    if plate == '' or #plate > 16 then return nil end
    return plate
end

local function safeIdentifier(identifier)
    return type(identifier) == 'string' and identifier ~= '' and identifier or nil
end

local function validVolume(value)
    value = tonumber(value)
    if not value or value < 0.0 or value > 1.0 then return nil end
    return math.floor(value * 1000 + 0.5) / 1000
end

local function getAccountMoney(xPlayer)
    if Config.PaymentAccount == 'money' or Config.PaymentAccount == 'cash' then
        return xPlayer.getMoney()
    end

    local account = xPlayer.getAccount(Config.PaymentAccount)
    return account and account.money or 0
end

local function removeMoney(xPlayer, amount)
    if Config.PaymentAccount == 'money' or Config.PaymentAccount == 'cash' then
        xPlayer.removeMoney(amount, 'backfire-tablet')
        return
    end

    xPlayer.removeAccountMoney(Config.PaymentAccount, amount, 'backfire-tablet')
end

local function addMoney(xPlayer, amount)
    if Config.PaymentAccount == 'money' or Config.PaymentAccount == 'cash' then
        xPlayer.addMoney(amount, 'backfire-tablet-refund')
        return
    end

    xPlayer.addAccountMoney(Config.PaymentAccount, amount, 'backfire-tablet-refund')
end

local function publicSettings(row)
    if not row then return nil end

    return {
        enabled = row.enabled == true or row.enabled == 1,
        frequency = frequencyById[row.frequency] and row.frequency or Config.DefaultSelection.frequency,
        color = colorById[row.color] and row.color or Config.DefaultSelection.color,
        sound = soundById[tostring(row.sound)] and tostring(row.sound) or tostring(Config.DefaultSelection.sound),
        size = sizeById[row.flame_size] and row.flame_size or Config.DefaultSelection.size,
        engineSound = engineSoundById[row.engine_sound] and row.engine_sound or Config.DefaultSelection.engineSound,
        shotVolume = validVolume(row.shot_volume) or Config.DefaultSelection.shotVolume
    }
end

local function getSettings(plate, bypassCache)
    if not bypassCache and settingsCache[plate] ~= nil then
        return settingsCache[plate] or nil
    end

    local row = MySQL.single.await([[
        SELECT `enabled`, `frequency`, `color`, `sound`, `flame_size`, `engine_sound`, `shot_volume`
        FROM `kr_backfire_vehicles`
        WHERE `plate` = ?
        LIMIT 1
    ]], { plate })

    local settings = publicSettings(row)
    settingsCache[plate] = settings or false
    return settings
end

local function validateVehicle(source, netId, plate, requireStopped)
    netId = tonumber(netId)
    plate = trimPlate(plate)

    if not netId or not plate then
        return nil, nil, 'Nieprawidłowe dane pojazdu.'
    end

    local vehicle = NetworkGetEntityFromNetworkId(netId)
    if vehicle == 0 or not DoesEntityExist(vehicle) then
        return nil, nil, 'Pojazd nie jest dostępny w sieci.'
    end

    local ped = GetPlayerPed(source)
    if ped == 0 or GetVehiclePedIsIn(ped, false) ~= vehicle then
        return nil, nil, 'Nie znajdujesz się w tym pojeździe.'
    end

    if Config.RequireDriverSeat and GetPedInVehicleSeat(vehicle, -1) ~= ped then
        return nil, nil, 'Musisz siedzieć na miejscu kierowcy.'
    end

    local serverPlate = trimPlate(GetVehicleNumberPlateText(vehicle))
    if serverPlate ~= plate then
        return nil, nil, 'Tablica rejestracyjna pojazdu nie zgadza się.'
    end

    -- GetVehicleClass is a GTA client native and is not available in a
    -- server script. Keep the detailed class filter client-side and use the
    -- OneSync server vehicle type here as the authoritative fallback.
    local vehicleType = GetVehicleType(vehicle)
    if vehicleType ~= 'automobile' then
        return nil, nil, 'Ten typ pojazdu nie obsługuje backfire.'
    end

    if blockedModels[GetEntityModel(vehicle)] then
        return nil, nil, 'Ten model nie obsługuje backfire.'
    end

    if requireStopped and GetEntitySpeed(vehicle) > Config.MaxPurchaseSpeed + 0.5 then
        return nil, nil, 'Zatrzymaj pojazd przed zakupem.'
    end

    return vehicle, plate
end

local function ownsVehicle(source, plate)
    if not Config.RequireVehicleOwnerForPurchase then return true end

    local xPlayer = ESX.GetPlayerFromId(source)
    if not xPlayer then return false end

    local query = ('SELECT `%s` FROM `%s` WHERE UPPER(TRIM(`%s`)) = ? LIMIT 1'):format(
        Config.OwnedVehicles.ownerColumn,
        Config.OwnedVehicles.table,
        Config.OwnedVehicles.plateColumn
    )
    local owner = MySQL.scalar.await(query, { plate })

    return owner ~= nil and owner == safeIdentifier(xPlayer.identifier)
end

local function hasTablet(source)
    if not Config.RequireTabletItem then return true end
    return (exports.ox_inventory:Search(source, 'count', Config.ItemName) or 0) > 0
end

local function setVehicleState(vehicle, settings)
    if vehicle == 0 or not DoesEntityExist(vehicle) then return end
    Entity(vehicle).state:set('kr_backfire', settings or false, true)
end

local function rateLimited(source, action, cooldown)
    local now = GetGameTimer()
    actionTimes[source] = actionTimes[source] or {}
    local last = actionTimes[source][action] or 0

    if now - last < cooldown then
        return true
    end

    actionTimes[source][action] = now
    return false
end

local function gridKey(bucket, x, y)
    return ('%s:%s:%s'):format(bucket, x, y)
end

local function rebuildPlayerGrid()
    local nextGrid = {}
    local cellSize = Config.SyncDistance

    for _, playerString in ipairs(GetPlayers()) do
        local playerId = tonumber(playerString)
        local ped = playerId and GetPlayerPed(playerId) or 0

        if ped ~= 0 then
            local coords = GetEntityCoords(ped)
            local key = gridKey(
                GetPlayerRoutingBucket(playerId),
                math.floor(coords.x / cellSize),
                math.floor(coords.y / cellSize)
            )

            nextGrid[key] = nextGrid[key] or {}
            nextGrid[key][#nextGrid[key] + 1] = playerId
        end
    end

    playerGrid = nextGrid
end

CreateThread(function()
    while true do
        rebuildPlayerGrid()
        Wait(500)
    end
end)

lib.callback.register('kr_backfire:getVehicleData', function(source, payload)
    if not schemaReady then
        return { ok = false, message = 'Baza Backfire jeszcze się uruchamia. Spróbuj ponownie za chwilę.' }
    end

    if not hasTablet(source) then
        return { ok = false, message = 'Nie masz przy sobie tabletu Backfire.' }
    end

    local vehicle, plate, errorMessage = validateVehicle(
        source,
        payload and payload.netId,
        payload and payload.plate,
        true
    )

    if not vehicle then
        return { ok = false, message = errorMessage }
    end

    if not ownsVehicle(source, plate) then
        return { ok = false, message = 'Możesz modyfikować wyłącznie swój pojazd.' }
    end

    local xPlayer = ESX.GetPlayerFromId(source)
    if not xPlayer then
        return { ok = false, message = 'Nie znaleziono danych gracza.' }
    end

    local settings = getSettings(plate)
    if settings then
        setVehicleState(vehicle, settings)
    end

    return {
        ok = true,
        installed = settings ~= nil,
        settings = settings,
        balance = getAccountMoney(xPlayer),
        engineAudioAvailable = engineAudioAvailable()
    }
end)

lib.callback.register('kr_backfire:getRuntimeSettings', function(source, payload)
    if not schemaReady then
        return { ok = false, message = 'Baza Backfire nie jest jeszcze gotowa.' }
    end

    local vehicle, plate, errorMessage = validateVehicle(
        source,
        payload and payload.netId,
        payload and payload.plate,
        false
    )

    if not vehicle then
        return { ok = false, message = errorMessage }
    end

    local settings = getSettings(plate)
    activeBySource[source] = {
        vehicle = vehicle,
        netId = tonumber(payload.netId),
        plate = plate,
        settings = settings
    }
    setVehicleState(vehicle, settings)

    return {
        ok = true,
        installed = settings ~= nil,
        settings = settings
    }
end)

lib.callback.register('kr_backfire:purchase', function(source, payload)
    if not schemaReady then
        return { ok = false, message = 'Baza Backfire nie jest jeszcze gotowa.' }
    end

    if not hasTablet(source) then
        return { ok = false, message = 'Nie masz przy sobie tabletu Backfire.' }
    end

    if rateLimited(source, 'purchase', Config.Security.purchaseCooldown) then
        return { ok = false, message = 'Odczekaj chwilę przed kolejnym zakupem.' }
    end

    if purchaseLocks[source] then
        return { ok = false, message = 'Poprzedni zakup jest jeszcze przetwarzany.' }
    end
    purchaseLocks[source] = true

    local function finish(response)
        purchaseLocks[source] = nil
        return response
    end

    local vehicle, plate, errorMessage = validateVehicle(
        source,
        payload and payload.netId,
        payload and payload.plate,
        true
    )

    if not vehicle then
        return finish({ ok = false, message = errorMessage })
    end

    if not ownsVehicle(source, plate) then
        return finish({ ok = false, message = 'Możesz modyfikować wyłącznie swój pojazd.' })
    end

    local frequency = frequencyById[payload and payload.frequency]
    local color = colorById[payload and payload.color]
    local sound = soundById[tostring(payload and payload.sound)]
    local size = sizeById[payload and payload.size]
    local engineSound = engineSoundById[payload and payload.engineSound]
    local shotVolume = validVolume(payload and payload.shotVolume)

    if not frequency or not color or not sound or not size or not engineSound or shotVolume == nil then
        return finish({ ok = false, message = 'Wybrano niedostępny wariant.' })
    end

    if Config.EngineAudio.requireResourceForPurchase and not engineAudioAvailable() then
        return finish({
            ok = false,
            message = ('Uruchom zasób %s przed zakupem dźwięku silnika.'):format(Config.EngineAudio.resource)
        })
    end

    local xPlayer = ESX.GetPlayerFromId(source)
    if not xPlayer then
        return finish({ ok = false, message = 'Nie znaleziono danych gracza.' })
    end

    local current = getSettings(plate, true)
    local total = 0
    local hasChanges = current == nil

    if not current then
        total = Config.InstallPrice
            + frequency.price
            + color.price
            + sound.price
            + size.price
            + engineSound.price
    else
        if current.frequency ~= frequency.id then total = total + frequency.price; hasChanges = true end
        if current.color ~= color.id then total = total + color.price; hasChanges = true end
        if tostring(current.sound) ~= sound.id then total = total + sound.price; hasChanges = true end
        if current.size ~= size.id then total = total + size.price; hasChanges = true end
        if current.engineSound ~= engineSound.id then total = total + engineSound.price; hasChanges = true end
        if math.abs((current.shotVolume or Config.DefaultSelection.shotVolume) - shotVolume) > 0.0005 then
            hasChanges = true
        end
    end

    if not hasChanges then
        return finish({
            ok = false,
            message = 'Ten zestaw jest już zamontowany.',
            balance = getAccountMoney(xPlayer)
        })
    end

    local balance = getAccountMoney(xPlayer)
    if balance < total then
        return finish({
            ok = false,
            message = ('Brakuje Ci %s%s.'):format(Config.Currency, total - balance),
            balance = balance
        })
    end

    if total > 0 then
        removeMoney(xPlayer, total)
    end

    local identifier = safeIdentifier(xPlayer.identifier)
    local saved, saveError = pcall(function()
        -- Przy aktualizacji istniejącego montażu pozostaw enabled bez zmian.
        -- Jedynie INSERT nowego montażu uruchamia backfire domyślnie.
        MySQL.prepare.await([[
            INSERT INTO `kr_backfire_vehicles`
                (`plate`, `owner`, `enabled`, `frequency`, `color`, `sound`, `flame_size`, `engine_sound`, `shot_volume`)
            VALUES (?, ?, 1, ?, ?, ?, ?, ?, ?)
            ON DUPLICATE KEY UPDATE
                `owner` = VALUES(`owner`),
                `frequency` = VALUES(`frequency`),
                `color` = VALUES(`color`),
                `sound` = VALUES(`sound`),
                `flame_size` = VALUES(`flame_size`),
                `engine_sound` = VALUES(`engine_sound`),
                `shot_volume` = VALUES(`shot_volume`),
                `updated_at` = CURRENT_TIMESTAMP
        ]], {
            plate,
            identifier,
            frequency.id,
            color.id,
            sound.id,
            size.id,
            engineSound.id,
            shotVolume
        })
    end)

    if not saved then
        if total > 0 then
            addMoney(xPlayer, total)
        end
        print(('[kr_backfire] Nie udało się zapisać zakupu dla %s: %s'):format(plate, saveError))
        return finish({
            ok = false,
            message = 'Błąd zapisu. Pieniądze zostały zwrócone.',
            balance = getAccountMoney(xPlayer)
        })
    end

    local settings = {
        enabled = current == nil or current.enabled == true,
        frequency = frequency.id,
        color = color.id,
        sound = sound.id,
        size = size.id,
        engineSound = engineSound.id,
        shotVolume = shotVolume
    }

    settingsCache[plate] = settings
    activeBySource[source] = {
        vehicle = vehicle,
        netId = tonumber(payload.netId),
        plate = plate,
        settings = settings
    }
    setVehicleState(vehicle, settings)

    return finish({
        ok = true,
        installed = true,
        settings = settings,
        paid = total,
        balance = getAccountMoney(xPlayer),
        message = total > 0
            and ('Konfiguracja kupiona za %s%s.'):format(Config.Currency, total)
            or 'Głośność strzałów została zapisana.'
    })
end)

lib.callback.register('kr_backfire:toggle', function(source, payload)
    if not schemaReady then
        return { ok = false, message = 'Baza Backfire nie jest jeszcze gotowa.' }
    end

    if not hasTablet(source) then
        return { ok = false, message = 'Nie masz przy sobie tabletu Backfire.' }
    end

    if rateLimited(source, 'toggle', Config.Security.toggleCooldown) then
        return { ok = false, message = 'Odczekaj chwilę.' }
    end

    local vehicle, plate, errorMessage = validateVehicle(
        source,
        payload and payload.netId,
        payload and payload.plate,
        true
    )

    if not vehicle then
        return { ok = false, message = errorMessage }
    end

    if not ownsVehicle(source, plate) then
        return { ok = false, message = 'Możesz modyfikować wyłącznie swój pojazd.' }
    end

    local settings = getSettings(plate, true)
    if not settings then
        return { ok = false, message = 'Backfire nie jest jeszcze zamontowany.' }
    end

    if type(payload) ~= 'table' or type(payload.enabled) ~= 'boolean' then
        return { ok = false, message = 'Nieprawidłowy stan przełącznika.' }
    end

    local requestedEnabled = payload.enabled
    if settings.enabled ~= requestedEnabled then
        local saved, affectedRows = pcall(MySQL.update.await,
            'UPDATE `kr_backfire_vehicles` SET `enabled` = ?, `updated_at` = CURRENT_TIMESTAMP WHERE `plate` = ?',
            { requestedEnabled and 1 or 0, plate }
        )

        if not saved or type(affectedRows) ~= 'number' or affectedRows < 1 then
            print(('[kr_backfire] Nie udało się zmienić stanu backfire dla %s: %s'):format(
                plate, tostring(affectedRows)
            ))
            return { ok = false, message = 'Nie udało się zapisać stanu backfire w bazie.' }
        end
    end

    settings.enabled = requestedEnabled

    settingsCache[plate] = settings
    activeBySource[source] = {
        vehicle = vehicle,
        netId = tonumber(payload.netId),
        plate = plate,
        settings = settings
    }
    setVehicleState(vehicle, settings)

    return {
        ok = true,
        settings = settings,
        message = settings.enabled and 'Backfire został włączony.' or 'Backfire został wyłączony.'
    }
end)

RegisterNetEvent('kr_backfire:server:shot', function(netId, sequenceStart, mode)
    local source = source
    local now = GetGameTimer()
    local lastShot = shotTimes[source] or 0
    local launch = mode == 'launch'

    if mode ~= nil and not launch then return end

    local minimumInterval = launch
        and math.max(Config.Security.minShotInterval, Config.Security.minLaunchInterval)
        or Config.Security.minShotInterval

    if now - lastShot < minimumInterval then return end
    shotTimes[source] = now

    local playLiftOff = false
    if sequenceStart == true and not launch then
        local lastLiftOff = liftOffTimes[source] or 0

        if now - lastLiftOff >= Config.Security.minLiftOffInterval then
            liftOffTimes[source] = now
            playLiftOff = true
        end
    end

    local active = activeBySource[source]
    if not active or active.netId ~= tonumber(netId) or not active.settings or not active.settings.enabled then
        return
    end

    local vehicle = NetworkGetEntityFromNetworkId(active.netId)
    local ped = GetPlayerPed(source)

    if vehicle == 0
        or not DoesEntityExist(vehicle)
        or ped == 0
        or GetVehiclePedIsIn(ped, false) ~= vehicle
        or GetPedInVehicleSeat(vehicle, -1) ~= ped
    then
        activeBySource[source] = nil
        return
    end

    if launch and GetEntitySpeed(vehicle) > Config.LaunchControl.maxSpeed + 0.75 then
        return
    end

    local sourceCoords = GetEntityCoords(vehicle)
    local sourceBucket = GetPlayerRoutingBucket(source)
    local settings = active.settings
    local cellSize = Config.SyncDistance
    local cellX = math.floor(sourceCoords.x / cellSize)
    local cellY = math.floor(sourceCoords.y / cellSize)
    local sent = {}

    for offsetX = -2, 2 do
        for offsetY = -2, 2 do
            local candidates = playerGrid[gridKey(sourceBucket, cellX + offsetX, cellY + offsetY)]

            if candidates then
                for i = 1, #candidates do
                    local target = candidates[i]

                    if not sent[target] then
                        sent[target] = true
                        local targetPed = GetPlayerPed(target)

                        if targetPed ~= 0 and GetPlayerRoutingBucket(target) == sourceBucket then
                            local distance = #(GetEntityCoords(targetPed) - sourceCoords)

                            if distance <= Config.SyncDistance then
                                TriggerClientEvent('kr_backfire:client:playShot', target, active.netId, {
                                    color = settings.color,
                                    sound = settings.sound,
                                    size = settings.size,
                                    engineSound = settings.engineSound,
                                    shotVolume = settings.shotVolume,
                                    liftOff = playLiftOff,
                                    launch = launch
                                })
                            end
                        end
                    end
                end
            end
        end
    end

    if not sent[source] then
        TriggerClientEvent('kr_backfire:client:playShot', source, active.netId, {
            color = settings.color,
            sound = settings.sound,
            size = settings.size,
            engineSound = settings.engineSound,
            shotVolume = settings.shotVolume,
            liftOff = playLiftOff,
            launch = launch
        })
    end
end)

AddEventHandler('playerDropped', function()
    local source = source
    activeBySource[source] = nil
    purchaseLocks[source] = nil
    actionTimes[source] = nil
    shotTimes[source] = nil
    liftOffTimes[source] = nil
end)
