CREATE TABLE IF NOT EXISTS `kr_backfire_vehicles` (
    `plate` VARCHAR(16) NOT NULL,
    `owner` VARCHAR(80) NOT NULL,
    `enabled` TINYINT(1) NOT NULL DEFAULT 1,
    `frequency` VARCHAR(24) NOT NULL DEFAULT 'street',
    `color` VARCHAR(24) NOT NULL DEFAULT 'green',
    `sound` VARCHAR(24) NOT NULL DEFAULT '2',
    `flame_size` VARCHAR(24) NOT NULL DEFAULT 'street',
    `engine_sound` VARCHAR(64) NOT NULL DEFAULT 'lg57mustangtv8',
    `shot_volume` DECIMAL(4,3) NOT NULL DEFAULT 1.000,
    `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    `updated_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (`plate`),
    KEY `idx_kr_backfire_owner` (`owner`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
