-- Opcjonalna migracja pojazdów ze starego bbv-antilag.
-- Najpierw uruchom install.sql, a dopiero później ten plik.

INSERT INTO `kr_backfire_vehicles`
    (`plate`, `owner`, `enabled`, `frequency`, `color`, `sound`)
SELECT
    UPPER(TRIM(`plate`)),
    COALESCE(NULLIF(`installer`, ''), 'legacy-bbv'),
    1,
    'street',
    'classic',
    '2'
FROM `bbv_antilag`
WHERE `antilag` = 1
  AND `plate` IS NOT NULL
  AND TRIM(`plate`) <> ''
ON DUPLICATE KEY UPDATE
    `enabled` = VALUES(`enabled`),
    `frequency` = VALUES(`frequency`),
    `color` = VALUES(`color`),
    `sound` = VALUES(`sound`),
    `updated_at` = CURRENT_TIMESTAMP;

