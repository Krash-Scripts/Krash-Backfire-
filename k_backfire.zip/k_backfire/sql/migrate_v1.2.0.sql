-- Opcjonalna ręczna migracja z wersji 1.1.0.
-- Zasób wykonuje tę samą migrację automatycznie podczas startu.

ALTER TABLE `kr_backfire_vehicles`
    ADD COLUMN IF NOT EXISTS `flame_size`
        VARCHAR(24) NOT NULL DEFAULT 'street' AFTER `sound`,
    ADD COLUMN IF NOT EXISTS `engine_sound`
        VARCHAR(64) NOT NULL DEFAULT 'lg57mustangtv8' AFTER `flame_size`;
