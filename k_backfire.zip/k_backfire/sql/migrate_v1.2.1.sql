-- Opcjonalna ręczna migracja z wersji 1.2.0.
-- Zasób wykonuje tę samą migrację automatycznie podczas startu.

ALTER TABLE `kr_backfire_vehicles`
    ADD COLUMN IF NOT EXISTS `shot_volume`
        DECIMAL(4,3) NOT NULL DEFAULT 1.000 AFTER `engine_sound`;
