const app = document.getElementById('app');
const optionsRoot = document.getElementById('options');
const sectionTitle = document.getElementById('section-title');
const sectionStep = document.getElementById('section-step');
const sectionDescription = document.getElementById('section-description');
const optionCount = document.getElementById('option-count');
const vehicleName = document.getElementById('vehicle-name');
const vehiclePlate = document.getElementById('vehicle-plate');
const balance = document.getElementById('balance');
const installState = document.getElementById('install-state');
const installStateText = document.getElementById('install-state-text');
const selectionName = document.getElementById('selection-name');
const enabledToggle = document.getElementById('enabled-toggle');
const switchRow = enabledToggle.closest('.switch-row');
const backfirePowerDescription = document.getElementById('backfire-power-description');
const compactEnabledToggle = document.getElementById('compact-enabled-toggle');
const compactSwitchRow = compactEnabledToggle.closest('.compact-power');
const compactPowerDescription = document.getElementById('compact-power-description');
const totalPrice = document.getElementById('total-price');
const priceLabel = document.getElementById('price-label');
const feedback = document.getElementById('feedback');
const purchaseButton = document.getElementById('purchase');
const purchaseLabel = document.getElementById('purchase-label');
const closeButton = document.getElementById('close');
const deviceClock = document.getElementById('device-clock');
const previewFrequency = document.getElementById('preview-frequency');
const previewColor = document.getElementById('preview-color');
const previewColorSwatch = document.getElementById('preview-color-swatch');
const previewSize = document.getElementById('preview-size');
const previewSound = document.getElementById('preview-sound');
const previewEngine = document.getElementById('preview-engine');
const previewMeter = document.getElementById('preview-meter');
const steps = [...document.querySelectorAll('.step')];

const titles = {
    frequency: 'Częstotliwość strzałów',
    color: 'Kolor efektu',
    sound: 'Brzmienie strzału',
    size: 'Skala efektu',
    engineSound: 'Dźwięk silnika',
    volume: 'Głośność',
    appearance: 'Wygląd tabletu'
};

const descriptions = {
    frequency: 'Ustaw intensywność i charakter pracy układu.',
    color: 'Nadaj płomieniowi indywidualny kolor projektu.',
    sound: 'Wybierz charakterystyczne brzmienie pojedynczego strzału.',
    size: 'Dopasuj długość i natężenie płomienia do samochodu.',
    engineSound: 'Przeszukaj katalog jednostek i wybierz nowe brzmienie silnika.',
    volume: 'Ustaw poziom dźwięków systemu zapisany dla tego pojazdu.',
    appearance: 'Twój osobisty motyw tabletu, niezależny od koloru płomieni i HUD-u.'
};

const sectionOrder = ['frequency', 'color', 'sound', 'size', 'engineSound', 'volume', 'appearance'];

const catalogKeys = {
    frequency: 'frequencies',
    color: 'colors',
    sound: 'sounds',
    size: 'sizes',
    engineSound: 'engineSounds'
};

const pricedSections = ['frequency', 'color', 'sound', 'size', 'engineSound'];

const state = {
    open: false,
    busy: false,
    section: 'frequency',
    engineQuery: '',
    vehicle: null,
    installed: false,
    settings: null,
    original: null,
    balance: 0,
    installPrice: 0,
    currency: '$',
    engineAudioAvailable: false,
    engineAudioResource: 'Audio_Pack',
    catalog: {
        frequencies: [],
        colors: [],
        sounds: [],
        sizes: [],
        engineSounds: []
    }
};

// Preferences belong to the tablet UI only. They never enter vehicle configuration or purchase requests.
const THEME_STORAGE_KEY = 'kr_backfire_tablet_visual_v2';
const SURFACE_PRESETS = [
    ['navy', 'Granat', '#0b1421', '#0e1828', '#142136'],
    ['graphite', 'Grafit', '#12151d', '#161a24', '#222937'],
    ['obsidian', 'Czerń', '#080a0f', '#0b0d13', '#141923']
];
const THEME_PRESETS = [
    ['#3b82f6', 'Niebieski'], ['#22c55e', 'Zielony'], ['#a855f7', 'Fiolet'],
    ['#f97316', 'Pomarańcz'], ['#ef4444', 'Czerwony'], ['#06b6d4', 'Cyjan']
];
function validHex(value) { return /^#[0-9a-fA-F]{6}$/.test(String(value)); }
function loadVisualSettings() {
    try {
        const saved = JSON.parse(localStorage.getItem(THEME_STORAGE_KEY) || '{}');
        return {
            color: validHex(saved.color) ? saved.color : '#3b82f6',
            surface: SURFACE_PRESETS.some(([id]) => id === saved.surface) ? saved.surface : 'navy',
            animations: saved.animations !== false
        };
    } catch (_) { return { color: '#3b82f6', surface: 'navy', animations: true }; }
}
let visualSettings = loadVisualSettings();
function applyVisualSettings() {
    const hex = validHex(visualSettings.color) ? visualSettings.color : '#3b82f6';
    const rgb = [1,3,5].map(i => parseInt(hex.substring(i,i+2),16));
    const bright = rgb.map(channel => Math.round(channel + (255-channel)*.28));
    document.documentElement.style.setProperty('--accent', hex);
    document.documentElement.style.setProperty('--accent-bright', `rgb(${bright.join(',')})`);
    document.documentElement.style.setProperty('--accent-soft', `rgba(${rgb.join(',')},.13)`);
    document.documentElement.style.setProperty('--accent-line', `rgba(${rgb.join(',')},.38)`);
    document.documentElement.style.setProperty('--accent-rgb', rgb.join(','));
    document.documentElement.dataset.surface = visualSettings.surface;
    document.documentElement.classList.toggle('no-motion', !visualSettings.animations);
    try { localStorage.setItem(THEME_STORAGE_KEY, JSON.stringify(visualSettings)); } catch (_) {}
}
function renderAppearance() {
    optionCount.textContent = 'Wygląd urządzenia';
    optionsRoot.innerHTML = `<div class="appearance-settings">
       <div class="appearance-heading"><span class="eyebrow">EKRAN / MOTYW</span><h3>Kolor akcentu</h3><p>Kolor przycisków i zaznaczeń tabletu. Nie zmienia barwy płomieni ani HUD-u.</p></div>
       <div class="theme-swatches">${THEME_PRESETS.map(([hex,name]) => `<button type="button" class="theme-swatch ${visualSettings.color.toLowerCase()===hex?'is-active':''}" data-theme="${hex}" aria-label="Motyw ${name}" title="${name}"><i style="background:${hex}"></i><span>${name}</span></button>`).join('')}</div>
       <div class="appearance-custom"><label for="tablet-custom-color">Własny kolor akcentu</label><input type="color" id="tablet-custom-color" value="${visualSettings.color}"><code id="tablet-color-hex">${visualSettings.color.toUpperCase()}</code></div>
       <div class="appearance-heading"><h3>Tło tabletu</h3><p>Zmienia także tła menu, kart, paneli i ekranu.</p></div>
       <div class="surface-presets">${SURFACE_PRESETS.map(([id,name,bg,sidebar,panel]) => `<button type="button" class="surface-preset ${visualSettings.surface===id?'is-active':''}" data-surface="${id}" aria-pressed="${visualSettings.surface===id}"><span class="surface-preview" style="--preview-bg:${bg};--preview-sidebar:${sidebar};--preview-panel:${panel}"></span><span>${name}</span></button>`).join('')}</div>
       <label class="appearance-motion"><span><strong>Animacje interfejsu</strong><small>Subtelne przejścia otwierania i wyboru.</small></span><input type="checkbox" id="tablet-motion" ${visualSettings.animations?'checked':''}></label>
       <button class="theme-reset" type="button" id="tablet-theme-reset">Przywróć domyślny wygląd</button>
    </div>`;
    optionsRoot.querySelectorAll('[data-theme]').forEach(button => button.addEventListener('click', () => {
        visualSettings.color = button.dataset.theme; applyVisualSettings(); renderAppearance();
    }));
    document.getElementById('tablet-custom-color').addEventListener('input', event => {
        if (!validHex(event.target.value)) return;
        visualSettings.color = event.target.value; applyVisualSettings();
        document.getElementById('tablet-color-hex').textContent = visualSettings.color.toUpperCase();
        optionsRoot.querySelectorAll('[data-theme]').forEach(button => button.classList.toggle('is-active', button.dataset.theme.toLowerCase()===visualSettings.color.toLowerCase()));
    });
    optionsRoot.querySelectorAll('[data-surface]').forEach(button => button.addEventListener('click', () => {
        visualSettings.surface = button.dataset.surface; applyVisualSettings(); renderAppearance();
    }));
    document.getElementById('tablet-motion').addEventListener('change', event => {
        visualSettings.animations = event.target.checked; applyVisualSettings();
    });
    document.getElementById('tablet-theme-reset').addEventListener('click', () => {
        visualSettings = { color: '#3b82f6', surface: 'navy', animations: true };
        applyVisualSettings(); renderAppearance();
    });
}
applyVisualSettings();

const soundPool = new Map();
const soundCursor = new Map();

function nui(event, payload = {}) {
    return fetch(`https://${GetParentResourceName()}/${event}`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json; charset=UTF-8' },
        body: JSON.stringify(payload)
    }).then((response) => response.json());
}

function escapeHtml(value) {
    return String(value)
        .replace(/&/g, '&amp;')
        .replace(/</g, '&lt;')
        .replace(/>/g, '&gt;')
        .replace(/"/g, '&quot;')
        .replace(/'/g, '&#039;');
}

function money(value) {
    const number = Number(value) || 0;
    return `${state.currency}${new Intl.NumberFormat('pl-PL').format(number)}`;
}

function optionList(section = state.section) {
    return state.catalog[catalogKeys[section]] || [];
}

function selectedId(section = state.section) {
    return state.settings?.[section] ?? null;
}

function findOption(section, id) {
    return optionList(section).find((option) => String(option.id) === String(id));
}

function normalizeSettings(settings) {
    const shotVolume = Math.max(0, Math.min(1, Number(settings.shotVolume ?? 1)));
    return {
        ...settings,
        sound: String(settings.sound),
        engineSound: String(settings.engineSound),
        shotVolume
    };
}

function setFeedback(message = '', type = '') {
    feedback.textContent = message;
    feedback.className = `feedback${type ? ` is-${type}` : ''}`;
}

function calculatePrice() {
    if (!state.settings) return 0;

    let total = state.installed ? 0 : state.installPrice;

    for (const section of pricedSections) {
        const selected = findOption(section, state.settings[section]);
        const originalId = state.original?.[section];

        if (!state.installed || String(originalId) !== String(state.settings[section])) {
            total += Number(selected?.price) || 0;
        }
    }

    return total;
}

function hasChanges() {
    if (!state.settings) return false;
    if (!state.installed) return true;

    if (pricedSections.some((section) =>
        String(state.original?.[section]) !== String(state.settings[section])
    )) return true;

    return Math.abs(
        Number(state.original?.shotVolume ?? 1) - Number(state.settings.shotVolume ?? 1)
    ) > 0.0005;
}

function selectionSummary() {
    const frequency = findOption('frequency', state.settings?.frequency);
    const color = findOption('color', state.settings?.color);
    const size = findOption('size', state.settings?.size);
    return [frequency?.label, color?.label, size?.label].filter(Boolean).join(' / ')
        || 'Wybierz konfigurację';
}

function updateSummary() {
    const frequency = findOption('frequency', state.settings?.frequency);
    const color = findOption('color', state.settings?.color);
    const size = findOption('size', state.settings?.size);
    const sound = findOption('sound', state.settings?.sound);
    const engine = findOption('engineSound', state.settings?.engineSound);
    const price = calculatePrice();

    const selectedColor = color?.hex || '#3b82f6';
    const previewScale = Number(size?.previewScale) || 1;
    const meterWidth = Math.max(28, Math.min(100, Math.round((previewScale / 1.35) * 100)));
    selectionName.textContent = selectionSummary();
    previewFrequency.textContent = frequency?.label || '—';
    previewColor.textContent = color?.label || '—';
    previewColorSwatch.style.setProperty('--swatch', selectedColor);
    previewSize.textContent = size?.label || '—';
    previewSound.textContent = sound?.label || '—';
    previewEngine.textContent = engine?.label || '—';
    previewMeter.style.width = `${meterWidth}%`;
    balance.textContent = money(state.balance);
    totalPrice.textContent = money(price);
    priceLabel.textContent = state.installed ? 'Koszt zmian' : 'Instalacja + konfiguracja';
    const onlyFreeChanges = state.installed && hasChanges() && price <= 0;
    purchaseLabel.textContent = onlyFreeChanges
        ? 'Zapisz ustawienia'
        : (state.installed ? 'Kup wybrane zmiany' : 'Kup i zamontuj');
    purchaseButton.disabled = state.busy || !hasChanges();
    purchaseButton.setAttribute('aria-busy', String(state.busy));

    installStateText.textContent = state.installed ? 'ZAINSTALOWANY' : 'NIEZAINSTALOWANY';
    installState.classList.toggle('is-installed', state.installed);
    enabledToggle.checked = Boolean(state.settings?.enabled);
    enabledToggle.disabled = !state.installed || state.busy;
    switchRow.classList.toggle('is-disabled', !state.installed || state.busy);
    compactEnabledToggle.checked = enabledToggle.checked;
    compactEnabledToggle.disabled = enabledToggle.disabled;
    compactSwitchRow.classList.toggle('is-disabled', enabledToggle.disabled);
    const powerDescription = !state.installed
        ? 'Dostępny po montażu'
        : (state.settings?.enabled ? 'Włączony dla tego pojazdu' : 'Wyłączony dla tego pojazdu');
    backfirePowerDescription.textContent = powerDescription;
    compactPowerDescription.textContent = powerDescription;
}

function optionTemplate(option) {
    const selected = String(selectedId()) === String(option.id);
    const colorDot = state.section === 'color'
        ? `<span class="color-dot" style="--swatch:${escapeHtml(option.hex)}"></span>`
        : '';
    const preview = state.section === 'sound'
        ? `<button type="button" class="sound-action" data-preview="${escapeHtml(option.id)}">ODSŁUCHAJ</button>`
        : '';
    const category = state.section === 'engineSound'
        ? `<span class="category-chip">${escapeHtml(option.category)}</span>`
        : '';

    return `
        <article class="option${selected ? ' is-selected' : ''}"
            data-option="${escapeHtml(option.id)}"
            role="button"
            tabindex="0"
            aria-pressed="${selected ? 'true' : 'false'}">
            ${colorDot}
            <div class="option-head">
                <h3>${escapeHtml(option.label)}</h3>
                <span class="option-price">${Number(option.price) === 0 ? 'GRATIS' : money(option.price)}</span>
            </div>
            ${category}
            <p>${escapeHtml(option.description)}</p>
            ${preview}
            <span class="selected-check" aria-hidden="true">WYBRANE</span>
        </article>
    `;
}

function volumeTemplate() {
    const percentage = Math.round(Number(state.settings?.shotVolume ?? 1) * 100);

    return `
        <div class="volume-grid">
            <article class="volume-card">
                <div class="volume-head">
                    <div>
                        <span class="eyebrow">DŹWIĘKI NUI</span>
                        <h3>Głośność strzałów</h3>
                    </div>
                    <output id="shot-volume-value">${percentage}%</output>
                </div>
                <input id="shot-volume" class="volume-slider" type="range"
                    min="0" max="100" step="5" value="${percentage}"
                    aria-label="Głośność strzałów">
                <div class="volume-scale"><span>Wyciszone</span><span>Maksimum</span></div>
                <p>Reguluje strzały oraz dźwięk odpuszczenia. Ustawienie zapisuje się osobno dla pojazdu.</p>
            </article>
            <article class="volume-card is-informational">
                <div class="volume-head">
                    <div>
                        <span class="eyebrow">PAKIET AWC</span>
                        <h3>Głośność silnika</h3>
                    </div>
                    <span class="native-badge">MIXER GTA</span>
                </div>
                <p>Podmiana silnika działa przez natywny bank audio GTA. FiveM nie udostępnia dla niego osobnego gainu per pojazd, dlatego poziom silnika ustawia się w samym Audio_Pack lub w mikserze gry.</p>
            </article>
        </div>
    `;
}

function renderOptions({ preserveScroll = false } = {}) {
    const previousScrollTop = optionsRoot.scrollTop;
    const currentSectionIndex = sectionOrder.indexOf(state.section);
    sectionTitle.textContent = titles[state.section];
    sectionDescription.textContent = descriptions[state.section];
    sectionStep.textContent = state.section === 'appearance'
        ? 'PREFERENCJE / EKRAN'
        : `KONFIGURACJA / ${String(currentSectionIndex + 1).padStart(2, '0')}`;
    optionsRoot.dataset.section = state.section;
    steps.forEach((step) => {
        // In compact navigation CSS hides the visible label; preserve accessible navigation names.
        step.setAttribute('aria-label', titles[step.dataset.target]);
        const active = step.dataset.target === state.section;
        step.classList.toggle('is-active', active);
        if (active) {
            step.setAttribute('aria-current', 'step');
        } else {
            step.removeAttribute('aria-current');
        }
    });

    document.querySelector('.checkout').classList.toggle('is-appearance', state.section === 'appearance');
    document.querySelector('.workspace').classList.toggle('is-appearance', state.section === 'appearance');
    if (state.section === 'appearance') {
        setFeedback('Zmiany wyglądu zapisują się automatycznie.');
        renderAppearance();
        return;
    }

    if (state.section === 'volume') {
        optionCount.textContent = '2 ustawienia systemowe';
        optionsRoot.innerHTML = volumeTemplate();
        optionsRoot.scrollTop = preserveScroll ? previousScrollTop : 0;

        const slider = document.getElementById('shot-volume');
        const output = document.getElementById('shot-volume-value');
        slider?.addEventListener('input', () => {
            state.settings.shotVolume = Number(slider.value) / 100;
            output.textContent = `${slider.value}%`;
            updateSummary();
            setFeedback();
        });
        return;
    }

    let options = optionList();
    let toolbar = '';

    if (state.section === 'engineSound') {
        const query = state.engineQuery.trim().toLocaleLowerCase('pl');
        if (query) {
            options = options.filter((option) =>
                `${option.label} ${option.category} ${option.description}`
                    .toLocaleLowerCase('pl')
                    .includes(query)
            );
        }

        const resourceState = state.engineAudioAvailable
            ? '<span class="resource-state is-ready">PAKIET AUDIO AKTYWNY</span>'
            : `<span class="resource-state is-missing">URUCHOM ${escapeHtml(state.engineAudioResource)}</span>`;

        toolbar = `
            <div class="engine-toolbar">
                <label>
                    <input id="engine-search" type="text" maxlength="48"
                        value="${escapeHtml(state.engineQuery)}"
                        placeholder="Szukaj po nazwie lub typie silnika…">
                </label>
                <span class="result-count">${options.length} / ${optionList().length}</span>
                ${resourceState}
            </div>
        `;
    }

    const empty = options.length === 0
        ? '<div class="empty-state">Nie znaleziono pasującego brzmienia.</div>'
        : '';

    optionCount.textContent = `${options.length} ${options.length === 1 ? 'opcja' : 'opcji'}`;
    optionsRoot.innerHTML = toolbar + options.map(optionTemplate).join('') + empty;
    optionsRoot.scrollTop = preserveScroll ? previousScrollTop : 0;

    const engineSearch = document.getElementById('engine-search');
    if (engineSearch) {
        engineSearch.addEventListener('input', () => {
            state.engineQuery = engineSearch.value;
            renderOptions();
            const nextInput = document.getElementById('engine-search');
            nextInput?.focus();
            nextInput?.setSelectionRange(state.engineQuery.length, state.engineQuery.length);
        });
    }

    optionsRoot.querySelectorAll('.option').forEach((element) => {
        element.addEventListener('keydown', (event) => {
            if (event.target.closest('[data-preview]')) return;
            if (event.key !== 'Enter' && event.key !== ' ') return;
            event.preventDefault();
            element.click();
        });

        element.addEventListener('click', (event) => {
            if (state.busy) return;
            const preview = event.target.closest('[data-preview]');
            const id = element.dataset.option;

            if (preview) {
                event.stopPropagation();
                nui('previewSound', {
                    sound: preview.dataset.preview,
                    shotVolume: state.settings.shotVolume
                });
                return;
            }

            state.settings[state.section] = id;
            renderOptions({ preserveScroll: true });
            updateSummary();
            setFeedback();
        });
    });
}

function applyServerState(payload) {
    state.installed = Boolean(payload.installed);
    state.settings = payload.settings
        ? normalizeSettings(payload.settings)
        : normalizeSettings({
            enabled: true,
            frequency: payload.defaults.frequency,
            color: payload.defaults.color,
            sound: payload.defaults.sound,
            size: payload.defaults.size,
            engineSound: payload.defaults.engineSound,
            shotVolume: payload.defaults.shotVolume
        });
    state.original = state.installed ? { ...state.settings } : null;
}

function open(payload) {
    state.open = true;
    state.busy = false;
    state.section = 'frequency';
    state.engineQuery = '';
    state.vehicle = payload.vehicle;
    state.balance = Number(payload.balance) || 0;
    state.installPrice = Number(payload.installPrice) || 0;
    state.currency = payload.currency || '$';
    state.engineAudioAvailable = Boolean(payload.engineAudioAvailable);
    state.engineAudioResource = payload.engineAudioResource || 'Audio_Pack';
    state.catalog = payload.catalog;

    applyServerState(payload);

    vehicleName.textContent = payload.vehicle.label;
    vehiclePlate.textContent = payload.vehicle.plate;
    app.classList.add('is-open');
    app.setAttribute('aria-hidden', 'false');
    setFeedback();
    renderOptions();
    updateSummary();
}

function close() {
    state.open = false;
    state.busy = false;
    app.classList.remove('is-open');
    app.setAttribute('aria-hidden', 'true');
}

function playSound(id, volume = 0.5) {
    const key = String(id);
    let pool = soundPool.get(key);

    if (!pool) {
        pool = Array.from({ length: 5 }, () => {
            const audio = new Audio(`sounds/${key}.ogg`);
            audio.preload = 'auto';
            return audio;
        });
        soundPool.set(key, pool);
        soundCursor.set(key, 0);
    }

    const cursor = soundCursor.get(key) || 0;
    const audio = pool[cursor];
    soundCursor.set(key, (cursor + 1) % pool.length);
    audio.currentTime = 0;
    audio.volume = Math.max(0, Math.min(1, Number(volume) || 0));
    audio.play().catch(() => {});
}

function updateDeviceClock() {
    deviceClock.textContent = new Intl.DateTimeFormat('pl-PL', {
        hour: '2-digit',
        minute: '2-digit'
    }).format(new Date());
}

updateDeviceClock();
setInterval(updateDeviceClock, 30000);

steps.forEach((step) => {
    step.addEventListener('click', () => {
        if (state.busy) return;
        const leavingAppearance = state.section === 'appearance';
        state.section = step.dataset.target;
        if (leavingAppearance) setFeedback();
        renderOptions();
    });
});

closeButton.addEventListener('click', () => nui('close'));

window.addEventListener('keydown', (event) => {
    if (event.key === 'Escape' && state.open) {
        nui('close');
    }
});

purchaseButton.addEventListener('click', async () => {
    const price = calculatePrice();
    if (state.busy || !hasChanges()) return;

    state.busy = true;
    updateSummary();
    setFeedback('Przetwarzanie płatności…');

    try {
        const response = await nui('purchase', {
            netId: state.vehicle.netId,
            plate: state.vehicle.plate,
            frequency: state.settings.frequency,
            color: state.settings.color,
            sound: state.settings.sound,
            size: state.settings.size,
            engineSound: state.settings.engineSound,
            shotVolume: state.settings.shotVolume
        });

        if (!response?.ok) {
            if (Number.isFinite(response?.balance)) state.balance = response.balance;
            setFeedback(response?.message || 'Zakup nie powiódł się.', 'error');
            return;
        }

        state.installed = true;
        state.settings = normalizeSettings(response.settings);
        state.original = { ...state.settings };
        state.balance = Number(response.balance) || 0;
        setFeedback(response.message, 'success');
        renderOptions();
    } catch {
        setFeedback('Brak odpowiedzi serwera.', 'error');
    } finally {
        state.busy = false;
        updateSummary();
    }
});

optionsRoot.addEventListener('wheel', (event) => {
    if (!state.open || optionsRoot.scrollHeight <= optionsRoot.clientHeight) return;
    optionsRoot.scrollTop += event.deltaY;
    event.preventDefault();
}, { passive: false });

async function changeBackfireState(control) {
    if (!state.installed || state.busy) {
        control.checked = Boolean(state.settings?.enabled);
        return;
    }

    // Capture the new checkbox value BEFORE updateSummary() renders state into the DOM.
    // Otherwise the old state overwrites the click and sends the opposite value to Lua.
    const desiredEnabled = control.checked;
    const previous = Boolean(state.settings.enabled);
    state.settings.enabled = desiredEnabled;
    state.busy = true;
    updateSummary();

    try {
        const response = await nui('toggle', {
            netId: state.vehicle.netId,
            plate: state.vehicle.plate,
            enabled: desiredEnabled
        });

        if (!response?.ok) {
            state.settings.enabled = previous;
            setFeedback(response?.message || 'Nie udało się zmienić stanu.', 'error');
            return;
        }

        state.settings.enabled = Boolean(response.settings.enabled);
        state.original.enabled = state.settings.enabled;
        setFeedback(response.message, 'success');
    } catch {
        state.settings.enabled = previous;
        setFeedback('Brak odpowiedzi serwera.', 'error');
    } finally {
        state.busy = false;
        updateSummary();
    }
}

enabledToggle.addEventListener('change', () => changeBackfireState(enabledToggle));
compactEnabledToggle.addEventListener('change', () => changeBackfireState(compactEnabledToggle));

window.addEventListener('message', (event) => {
    const data = event.data || {};

    if (data.action === 'open') open(data.payload);
    if (data.action === 'close') close();
    if (data.action === 'playSound') playSound(data.sound, data.volume);
});
