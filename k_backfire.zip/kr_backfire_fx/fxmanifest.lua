fx_version 'cerulean'
game 'gta5'

author 'KR4SH'
description 'Uniquely named tint-ready backfire and nitrous particle assets for KR Backfire'
version '1.8.0'

files {
    'stream/krbf_core.ypt',
    'stream/krbf_nitro.ypt'
}
